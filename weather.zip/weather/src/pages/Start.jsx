import React from 'react'
import '../styles/Start.css'
import logo from '../images/logo.png'
import { useNavigate } from 'react-router-dom'

export const Start = () => {
  const navigate = useNavigate();

  const startApp = () => {
    navigate('/Main');
  };

  setTimeout(() => {
    startApp()
  },4000)

  return (
    <div className='start'>
      <img src={logo} />
    </div>
  )
}
