import React, { useEffect, useState } from 'react'

export const Main = () => {
    const [weatherData, setWeatherData] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            const url = 'https://weatherapi-com.p.rapidapi.com/forecast.json?q=Sarajevo&days=3';
            const options = {
                method: 'GET',
                headers: {
                    'X-RapidAPI-Key': '39ed008c45msh57a563bbc163d77p10896ejsn72ba0f1b7281',
                    'X-RapidAPI-Host': 'weatherapi-com.p.rapidapi.com'
                }
            };

            try {
                const response = await fetch(url, options);
                const result = await response.json();
                console.log(result);
                setWeatherData(result);
            } catch (error) {
                console.error(error);
            }
        };

        fetchData();
    }, []);

    console.log(weatherData)

    //

    const [currentTime, setCurrentTime] = useState(new Date());

    useEffect(() => {
        const intervalId = setInterval(() => {
        setCurrentTime(new Date());
        }, 60000); 

        return () => clearInterval(intervalId);
    }, []); 

    const formatTime = (date) => {
        const hours = date.getHours().toString().padStart(2, '0');
        const minutes = date.getMinutes().toString().padStart(2, '0');
        return `${hours}:${minutes}`;
    };

  return (
    <div className='app'>
        <div className='sec-1'>
            <h1 id='sec-1-clock'>{formatTime(currentTime)}</h1>
            <hr/>
            {weatherData && weatherData.location.name && (
                <p id='sec-1-date'>
                    {weatherData.location.localtime.slice(0, -5)}
                </p>
            )}<p id='sec-1-location'>{weatherData && weatherData.location.name},{weatherData && weatherData.location.country}</p>
            
        </div>
    </div>
  )
}
